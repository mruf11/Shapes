package edu.cvtc.java;

public class Cylinder {

    // Attributes
    private float radius, height;

    //Constructor using radius and height
    public Cylinder(float radius, float height) {
        this.radius = radius;
        this.height = height;
    }

    // calculating Surface area
    public float getCylinderSurfaceArea() { return (float)((2 * Math.PI * radius * height) + (2 * Math.PI * Math.pow(radius, 2))); }

    public float getCylinderVolume() { return (float)(Math.PI * Math.pow(radius,2) * height);}
}
