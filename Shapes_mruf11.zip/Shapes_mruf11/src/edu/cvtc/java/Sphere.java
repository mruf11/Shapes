package edu.cvtc.java;

public class Sphere {

    //Attributes
    private float radius;

    //Constructor
    public Sphere(float radius) {
        this.radius = radius;
    }

    public float getSphereSurfaceArea() { return (float)(4 * Math.PI *(Math.pow(radius,2)));}

    public float getSphereVolume() { return (float)(4/3 * Math.PI * Math.pow(radius, 3));}

}
