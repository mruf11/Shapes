package edu.cvtc.java;

public class ShapesTest {
    public static void main(String[] args) {

        Cuboid cuboid = new Cuboid(5,9,3);

        Cylinder cylinder = new Cylinder(6,4);

        Sphere sphere = new Sphere(9);

        System.out.println("the Volume of the Cuboid is " + cuboid.getCuboidVolume());
        System.out.println("the Surface Area of the Cuboid is " + cuboid.getCuboidSurfaceArea());

        System.out.println("the Volume of the Cylinder is " + cylinder.getCylinderVolume());
        System.out.println("the Surface Area of the Cylinder is " + cylinder.getCylinderSurfaceArea());

        System.out.println("the Volume of the Sphere is " + sphere.getSphereVolume());
        System.out.println("the Surface Area of the Sphere is " + sphere.getSphereSurfaceArea());

    }
}
