package edu.cvtc.java;

public class Cuboid {

    // Attributes
    private float width, height, depth;

    // Constructors for the attributes

    public Cuboid(float width, float height, float depth) {
        this.width = width;
        this.height = height;
        this.depth = depth;
    }

    // Calculating the Surface Area
    public float getCuboidSurfaceArea() { return 2 * ((depth*width) + (width*height) + (depth*height)); }

    // Calculating the Volume
    public float getCuboidVolume() { return depth * height * width; }

}
